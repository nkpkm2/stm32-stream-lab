# R2-W3 bounded dynamic-DBM rebinding package

This package is based on the user's exact 14-file snapshot at
`a966cd3e78b4f190ca731daea8388463d39f7486`.

## Current verification boundary

The source ZIP SHA256 and all 14 file hashes were verified.
Linux GCC Debug: 62/62 W1+W2+W3 native tests passed.
Linux Clang Release + AddressSanitizer/UndefinedBehaviorSanitizer: 62/62 passed.
The actual new adapter C was compiled against explicit API shims and tested
in eight mocked-register sequencing scenarios with GCC and Clang sanitizers.
These shims are not vendor headers or a timing simulator.

The real Windows/MSVC native run, ARM/CubeF4 build/link, PowerShell 5.1
execution and board tests have NOT been performed here. No hardware PASS
is claimed. Real hardware execution is the next distinct work step.

## Installation only

Extract to a temporary directory and run `install_r2_w3.ps1 -Repo <repo>`
from Windows PowerShell. Parse-check the installer before invoking it.
The installer also parse-checks the payload PowerShell script before writes.

Preconditions: expected HEAD, clean main working tree, correct R0/R1 tags,
no r2-pass, exact snapshot and payload hashes. It copies ten files and verifies
all other tracked file bytes remain unchanged. No add/commit/push/build/MCU
operation occurs. Failure after writes triggers rollback of this install's
files only. The caller's working directory is not changed.

## Installed files

New:
- firmware/acquisition/r2_w3_guard.h
- firmware/acquisition/r2_w3_rebind.h
- firmware/acquisition/r2_w3_rebind.c
- tests/native/test_r2_w3_guard.c
- tools/r2/verify_w3.ps1
- docs/evidence/r2/w3/PLAN.md

Selectively replaced from exact snapshot:
- firmware/cubemx/CMakeLists.txt
- firmware/cubemx/Core/Src/main.c
- firmware/cubemx/Core/Src/stm32f4xx_it.c
- tests/native/CMakeLists.txt

The four R1 source/header files, W1/W2 production modules, IOC, HAL,
FreeRTOS and generated peripheral configuration are not replaced.

The default target remains R1. W3 requires the explicit
`STREAM_LAB_R2_W3=ON` build option. W3 and R1 never own the DMA simultaneously.

## Experiment

Fixed K=8/P=10, 200 kS/s, N=256. Eight one-use replacements B2..B9. After
write 8 stop new triggers, quiesce DMA, keep eight completed blocks and all
trace data in RAM. No consumer, queue, recycling, drop campaign or R3 work.

Read `payload/docs/evidence/r2/w3/PLAN.md` for source ownership, safety checks,
timing interpretation and the precise limits of this diagnostic experiment.

After installation STOP and return the installation output. The build-only
runner is in the repository, so it will not be lost when Downloads is cleared.
Keep this package's verification files until host-test evidence is archived.
