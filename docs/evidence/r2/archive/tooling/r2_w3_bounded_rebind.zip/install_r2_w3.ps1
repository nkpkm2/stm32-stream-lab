[CmdletBinding()]
param([string]$Repo = 'E:\Projects\stm32-stream-lab')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$Git = (Get-Command git.exe -ErrorAction Stop).Source
$manifestPath = Join-Path $PSScriptRoot 'package-manifest.json'
$manifest = [System.IO.File]::ReadAllText($manifestPath) | ConvertFrom-Json
$Repo = (Resolve-Path -LiteralPath $Repo).Path
$written = New-Object System.Collections.Generic.List[string]
$originals = @{}
$trackedBefore = @{}

function Git-Lines {
    param([string[]]$Arguments)
    $old = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $lines = @(& $Git -C $Repo @Arguments)
        $rc = $LASTEXITCODE
    } finally { $ErrorActionPreference = $old }
    if ($rc -ne 0) { throw ('Git failed: {0}' -f ($Arguments -join ' ')) }
    return $lines
}
function File-Hash {
    param([string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
}
try {
    Write-Host '=== R2-W3 BOUNDED REBINDING INSTALLATION ==='
    if (@($manifest.files).Count -ne 10) { throw 'Unexpected package file count.' }
    $head = @(Git-Lines -Arguments @('rev-parse','HEAD'))
    if ($head.Count -ne 1 -or $head[0] -ne $manifest.expected_head) { throw 'Unexpected baseline HEAD.' }
    $branch = @(Git-Lines -Arguments @('branch','--show-current'))
    if ($branch.Count -ne 1 -or $branch[0] -ne 'main') { throw 'Expected branch main.' }
    $status = @(Git-Lines -Arguments @('status','--porcelain=v1','--untracked-files=all'))
    if ($status.Count -ne 0) { $status | Write-Host; throw 'Working tree is not clean.' }
    $r0 = @(Git-Lines -Arguments @('rev-parse','r0-pass^{commit}'))
    $r1 = @(Git-Lines -Arguments @('rev-parse','r1-pass^{commit}'))
    if ($r0[0] -ne $manifest.r0_firmware -or $r1[0] -ne $manifest.r1_firmware) {
        throw 'R0/R1 gate target mismatch.'
    }
    if (@(Git-Lines -Arguments @('tag','--list','r2-pass')).Count -ne 0) { throw 'r2-pass must not exist.' }
    $indexBefore = @(Git-Lines -Arguments @('write-tree'))[0]
    foreach ($entry in $manifest.snapshot) {
        $path = Join-Path $Repo $entry.path
        if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or
            (File-Hash -Path $path) -ne $entry.sha256) {
            throw ('Snapshot mismatch: {0}' -f $entry.path)
        }
    }
    $replacements = @{}
    $expected = @()
    foreach ($entry in $manifest.files) {
        $rel = [string]$entry.path
        if ([System.IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[/\\])\.\.([/\\]|$)') {
            throw 'Unsafe package path.'
        }
        if ($expected -contains $rel) { throw 'Duplicate package path.' }
        $expected += $rel
        $payload = Join-Path (Join-Path $PSScriptRoot 'payload') $rel
        if (-not (Test-Path -LiteralPath $payload -PathType Leaf) -or
            (File-Hash -Path $payload) -ne $entry.sha256) {
            throw ('Payload hash/file mismatch: {0}' -f $rel)
        }
        $destination = Join-Path $Repo $rel
        if ($entry.action -eq 'replace') {
            if (-not (Test-Path -LiteralPath $destination -PathType Leaf) -or
                (File-Hash -Path $destination) -ne $entry.original_sha256) {
                throw ('Replace precondition failed: {0}' -f $rel)
            }
            $replacements[$rel] = $true
            $originals[$rel] = [System.IO.File]::ReadAllBytes($destination)
        } elseif ($entry.action -eq 'new') {
            if (Test-Path -LiteralPath $destination) { throw ('New path already exists: {0}' -f $rel) }
        } else { throw 'Unknown manifest action.' }
    }
    # Parse every PowerShell payload BEFORE any repository copy.
    foreach ($entry in $manifest.files) {
        if ([string]$entry.path -like '*.ps1') {
            $tokens = $null
            $parseErrors = $null
            $path = Join-Path (Join-Path $PSScriptRoot 'payload') $entry.path
            [System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$parseErrors) | Out-Null
            if (@($parseErrors).Count -ne 0) { $parseErrors | Format-List; throw 'PowerShell payload parser check failed.' }
        }
    }
    foreach ($rel in @(Git-Lines -Arguments @('ls-files'))) {
        $trackedBefore[$rel] = File-Hash -Path (Join-Path $Repo $rel)
    }
    Write-Host ('Snapshot SHA256: {0}/{0} verified' -f @($manifest.snapshot).Count)
    Write-Host ('Payload SHA256: {0}/{0} verified' -f $expected.Count)
    foreach ($entry in $manifest.files) {
        $rel = [string]$entry.path
        $destination = Join-Path $Repo $rel
        $parent = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }
        $written.Add($rel)
        Copy-Item -LiteralPath (Join-Path (Join-Path $PSScriptRoot 'payload') $rel) -Destination $destination -Force
        if ((File-Hash -Path $destination) -ne $entry.sha256) { throw ('Copy verification failed: {0}' -f $rel) }
    }
    foreach ($rel in $trackedBefore.Keys) {
        if (-not $replacements.ContainsKey($rel) -and
            (File-Hash -Path (Join-Path $Repo $rel)) -ne $trackedBefore[$rel]) {
            throw ('Protected tracked bytes changed: {0}' -f $rel)
        }
    }
    $status = @(Git-Lines -Arguments @('status','--porcelain=v1','--untracked-files=all'))
    $actual = @($status | ForEach-Object { $_.Substring(3) } | Sort-Object)
    $difference = @(Compare-Object -ReferenceObject @($expected | Sort-Object) -DifferenceObject $actual)
    if ($difference.Count -ne 0) { $difference | Format-Table; throw 'Unexpected installation scope.' }
    if (@(Git-Lines -Arguments @('write-tree'))[0] -ne $indexBefore) { throw 'Index content changed.' }
    if (@(Git-Lines -Arguments @('rev-parse','HEAD'))[0] -ne $manifest.expected_head) { throw 'HEAD changed.' }
    if (@(Git-Lines -Arguments @('rev-parse','r1-pass^{commit}'))[0] -ne $manifest.r1_firmware) { throw 'R1 tag moved.' }
    Write-Host ''
    Write-Host 'R2-W3 BOUNDED REBINDING INSTALLATION: PASS'
    Write-Host ('Repository files: {0}; replacements: {1}; new: {2}' -f $expected.Count,$replacements.Count,($expected.Count-$replacements.Count))
    Write-Host 'Protected tracked file bytes: unchanged'
    Write-Host 'R1 driver/harness, W1/W2 modules, IOC, FreeRTOS: unchanged'
    Write-Host 'Default firmware profile: R1; W3 requires STREAM_LAB_R2_W3=ON'
    Write-Host 'W3 hardware experiment: NOT BUILT OR RUN'
    Write-Host 'Host runner installed: tools/r2/verify_w3.ps1'
    Write-Host 'Staging content and gate targets: unchanged'
    Write-Host 'No build, flash, reset, commit, push, or MCU operation.'
} catch {
    $reason = $_.Exception.Message
    Write-Host ''
    Write-Host 'R2-W3 BOUNDED REBINDING INSTALLATION: FAIL'
    Write-Host $reason
    if ($written.Count -gt 0) {
        $rollbackOk = $true
        for ($i = $written.Count - 1; $i -ge 0; --$i) {
            $rel = $written[$i]
            $destination = Join-Path $Repo $rel
            try {
                if ($originals.ContainsKey($rel)) {
                    [System.IO.File]::WriteAllBytes($destination,[byte[]]$originals[$rel])
                } elseif (Test-Path -LiteralPath $destination -PathType Leaf) {
                    Remove-Item -LiteralPath $destination -Force
                }
            } catch { $rollbackOk = $false; Write-Host ('Rollback error: {0}' -f $rel) }
        }
        if ($rollbackOk) { Write-Host 'Files written by this installer were rolled back.' }
        else { Write-Host 'Rollback was incomplete. Preserve the directory and report the output.' }
    }
    Write-Host 'Do not build or flash on an installation failure.'
    exit 1
}
