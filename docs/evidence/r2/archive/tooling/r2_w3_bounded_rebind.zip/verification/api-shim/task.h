#include "FreeRTOS.h"
void vTaskDelay(TickType_t);
TickType_t xTaskGetTickCount(void);
TaskHandle_t xTaskCreateStatic(void (*)(void *), const char *, uint32_t, void *, uint32_t, StackType_t *, StaticTask_t *);
