#ifndef SHIM_MAIN_H
#define SHIM_MAIN_H
/* Compile-only API shim. NOT vendor headers and NOT hardware simulation. */
#include <stdint.h>
#include <stddef.h>
typedef enum { HAL_OK, HAL_ERROR, HAL_BUSY, HAL_TIMEOUT } HAL_StatusTypeDef;
typedef struct { volatile uint32_t CR, NDTR, PAR, M0AR, M1AR, FCR; } DMA_Stream_TypeDef;
typedef struct { volatile uint32_t LISR, LIFCR; } DMA_TypeDef;
typedef struct { volatile uint32_t CR1, CR2, DIER, PSC, ARR, CNT, SR; } TIM_TypeDef;
typedef struct { volatile uint32_t CR1, CR2, SR, DR, SQR1, SQR3, SMPR2; } ADC_TypeDef;
typedef struct DMA_HandleTypeDef DMA_HandleTypeDef;
struct DMA_HandleTypeDef { DMA_Stream_TypeDef *Instance; uint32_t State; void (*XferCpltCallback)(DMA_HandleTypeDef *); void (*XferM1CpltCallback)(DMA_HandleTypeDef *); void (*XferHalfCpltCallback)(DMA_HandleTypeDef *); void (*XferM1HalfCpltCallback)(DMA_HandleTypeDef *); void (*XferErrorCallback)(DMA_HandleTypeDef *); void (*XferAbortCallback)(DMA_HandleTypeDef *); };
typedef struct { ADC_TypeDef *Instance; DMA_HandleTypeDef *DMA_Handle; struct { uint32_t ClockPrescaler, Resolution, ContinuousConvMode, DMAContinuousRequests, ExternalTrigConv, ExternalTrigConvEdge; } Init; } ADC_HandleTypeDef;
typedef struct { TIM_TypeDef *Instance; } TIM_HandleTypeDef;
typedef struct { volatile uint32_t CTRL, CYCCNT; } DWT_Type;
typedef struct { volatile uint32_t DEMCR; } CoreDebug_Type;
typedef struct { volatile uint32_t AIRCR; } SCB_Type;
extern DMA_TypeDef *DMA2;
extern DMA_Stream_TypeDef *DMA2_Stream0;
extern TIM_TypeDef *TIM2;
extern ADC_TypeDef *ADC1;
extern DWT_Type *DWT;
extern CoreDebug_Type *CoreDebug;
extern SCB_Type *SCB;
#define DMA_LISR_FEIF0 1U
#define DMA_LISR_DMEIF0 4U
#define DMA_LISR_TEIF0 8U
#define DMA_LISR_HTIF0 16U
#define DMA_LISR_TCIF0 32U
#define DMA_SxCR_EN 1U
#define DMA_SxCR_DMEIE 2U
#define DMA_SxCR_TEIE 4U
#define DMA_SxCR_HTIE 8U
#define DMA_SxCR_TCIE 16U
#define DMA_SxCR_DBM 0x40000U
#define DMA_SxCR_CT 0x80000U
#define DMA_SxFCR_FEIE 0x80U
#define ADC_CR1_EOCIE 0x20U
#define ADC_CR1_OVRIE 0x04000000U
#define ADC_CR2_ADON 1U
#define ADC_CR2_DMA 0x100U
#define ADC_SR_OVR 0x20U
#define ADC_FLAG_OVR 0x20U
#define ADC_FLAG_EOC 2U
#define ADC_CLOCK_SYNC_PCLK_DIV4 0x10000U
#define ADC_RESOLUTION_12B 0U
#define ADC_EXTERNALTRIGCONV_T2_TRGO 0x06000000U
#define ADC_EXTERNALTRIGCONVEDGE_RISING 0x10000000U
#define ADC_SMPR2_SMP0 7U
#define ADC_SAMPLETIME_28CYCLES 2U
#define TIM_CR1_CEN 1U
#define TIM_CR2_MMS 0x70U
#define TIM_TRGO_UPDATE 0x20U
#define TIM_FLAG_UPDATE 1U
#define DMA_IT_HT 8U
#define DMA2_Stream0_IRQn 56U
#define NVIC_PRIORITYGROUP_4 3U
#define HAL_DMA_STATE_READY 1U
#define ENABLE 1U
#define DISABLE 0U
#define CoreDebug_DEMCR_TRCENA_Msk 0x1000000U
#define DWT_CTRL_CYCCNTENA_Msk 1U
#define CLEAR_BIT(r,b) ((r) &= ~(b))
#define SET_BIT(r,b) ((r) |= (b))
#define __HAL_TIM_SET_COUNTER(t,v) ((t)->Instance->CNT = (v))
#define __HAL_TIM_CLEAR_FLAG(t,v) ((t)->Instance->SR = ~(v))
#define __HAL_ADC_CLEAR_FLAG(a,v) ((a)->Instance->SR = ~(v))
#define __HAL_DMA_DISABLE_IT(d,v) ((d)->Instance->CR &= ~(v))
uint32_t __get_PRIMASK(void);
void __disable_irq(void);
void __set_PRIMASK(uint32_t);
void __DSB(void);
void __NOP(void);
uint32_t HAL_RCC_GetPCLK1Freq(void);
uint32_t HAL_RCC_GetPCLK2Freq(void);
uint32_t HAL_NVIC_GetPriorityGrouping(void);
uint32_t NVIC_GetPriority(uint32_t);
void HAL_NVIC_ClearPendingIRQ(uint32_t);
HAL_StatusTypeDef HAL_TIM_Base_Start(TIM_HandleTypeDef *);
HAL_StatusTypeDef HAL_TIM_Base_Stop(TIM_HandleTypeDef *);
HAL_StatusTypeDef HAL_ADC_Start(ADC_HandleTypeDef *);
HAL_StatusTypeDef HAL_ADC_Stop_DMA(ADC_HandleTypeDef *);
extern uint32_t SystemCoreClock;
#endif
