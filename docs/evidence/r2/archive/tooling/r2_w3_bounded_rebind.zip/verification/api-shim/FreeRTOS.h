#ifndef SHIM_RTOS_H
#define SHIM_RTOS_H
#include <stdint.h>
typedef uint32_t TickType_t;
typedef uint32_t StackType_t;
typedef struct { uint32_t dummy[40]; } StaticTask_t;
typedef void *TaskHandle_t;
#define pdMS_TO_TICKS(x) ((TickType_t)(x))
#define tskIDLE_PRIORITY 0U
#endif
