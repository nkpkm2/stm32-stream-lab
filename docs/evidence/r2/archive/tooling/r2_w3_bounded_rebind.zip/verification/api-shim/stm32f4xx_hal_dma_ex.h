#include "main.h"
HAL_StatusTypeDef HAL_DMAEx_MultiBufferStart_IT(DMA_HandleTypeDef *, uint32_t, uint32_t, uint32_t, uint32_t);
