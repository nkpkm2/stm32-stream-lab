/* Test actual W3 adapter C against compile-only API shims and RAM registers.
 * Not a model of STM32 bus timing, flag-clearing, interrupt latency, or HAL. */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "../payload/firmware/acquisition/r2_w3_rebind.c"
static DMA_TypeDef dma_regs;
static DMA_Stream_TypeDef stream_regs;
static ADC_TypeDef adc_regs;
static TIM_TypeDef tim_regs;
static DWT_Type dwt_regs;
static CoreDebug_Type core_regs;
static SCB_Type scb_regs;
DMA_TypeDef *DMA2 = &dma_regs;
DMA_Stream_TypeDef *DMA2_Stream0 = &stream_regs;
ADC_TypeDef *ADC1 = &adc_regs;
TIM_TypeDef *TIM2 = &tim_regs;
DWT_Type *DWT = &dwt_regs;
CoreDebug_Type *CoreDebug = &core_regs;
SCB_Type *SCB = &scb_regs;
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;
TIM_HandleTypeDef htim2;
uint32_t SystemCoreClock = 180000000U;
static uint32_t mask;
uint32_t __get_PRIMASK(void) { return mask; }
void __disable_irq(void) { mask = 1U; }
void __set_PRIMASK(uint32_t p) { mask = p; }
void __DSB(void) {}
void __NOP(void) { ++DWT->CYCCNT; }
uint32_t HAL_RCC_GetPCLK1Freq(void) { return 45000000U; }
uint32_t HAL_RCC_GetPCLK2Freq(void) { return 90000000U; }
uint32_t HAL_NVIC_GetPriorityGrouping(void) { return 3U; }
uint32_t NVIC_GetPriority(uint32_t n) { (void)n; return 5U; }
void HAL_NVIC_ClearPendingIRQ(uint32_t n) { (void)n; }
HAL_StatusTypeDef HAL_TIM_Base_Start(TIM_HandleTypeDef *t) { t->Instance->CR1 |= 1U; return HAL_OK; }
HAL_StatusTypeDef HAL_TIM_Base_Stop(TIM_HandleTypeDef *t) { t->Instance->CR1 &= ~1U; return HAL_OK; }
HAL_StatusTypeDef HAL_ADC_Start(ADC_HandleTypeDef *a) { a->Instance->CR2 |= 1U; return HAL_OK; }
HAL_StatusTypeDef HAL_ADC_Stop_DMA(ADC_HandleTypeDef *a) { a->Instance->CR2 &= ~257U; stream_regs.CR &= ~1U; return HAL_OK; }
HAL_StatusTypeDef HAL_DMAEx_MultiBufferStart_IT(DMA_HandleTypeDef *d,uint32_t s,uint32_t m0,uint32_t m1,uint32_t len) {
    d->Instance->PAR=s;d->Instance->M0AR=m0;d->Instance->M1AR=m1;d->Instance->NDTR=len;d->Instance->CR=W3_DMA_REQUIRED_CR;return HAL_OK;
}
void vTaskDelay(TickType_t ticks) { (void)ticks; }
TickType_t xTaskGetTickCount(void) { return 0U; }
TaskHandle_t xTaskCreateStatic(void (*t)(void *), const char *n,uint32_t a,void *b,uint32_t c,StackType_t *d,StaticTask_t *e) {
    (void)t;(void)n;(void)a;(void)b;(void)c;(void)d;return e;
}
#define CHECK(x) do { if (!(x)) { fprintf(stderr,"Mock FAIL %d: %s\n",__LINE__,#x);return 1; } } while (0)
static void Setup(void)
{
    uint32_t i,j;
    memset((void *)&g_r2_w3_result,0,sizeof(g_r2_w3_result));
    memset(&dma_regs,0,sizeof dma_regs);memset(&stream_regs,0,sizeof stream_regs);
    memset(&adc_regs,0,sizeof adc_regs);memset(&tim_regs,0,sizeof tim_regs);
    memset(&hadc1,0,sizeof hadc1);memset(&hdma_adc1,0,sizeof hdma_adc1);
    hdma_adc1.Instance=DMA2_Stream0;hadc1.Instance=ADC1;htim2.Instance=TIM2;
    hadc1.DMA_Handle=&hdma_adc1;mask=0U;
    R2_BufferPool_Reset();R2_DmaSlots_Reset();
    (void)R2_BufferPool_Activate(8U);(void)R2_DmaSlots_Initialize(0U,1U);
    for(i=0U;i<10U;++i){r2_w3_buffers[i].guard_lo=W3_GUARD_LO;r2_w3_buffers[i].guard_hi=W3_GUARD_HI;
        for(j=0U;j<256U;++j){r2_w3_buffers[i].samples[j]=W3_SENTINEL;}}
    stream_regs.M0AR=Address(0U);stream_regs.M1AR=Address(1U);
    stream_regs.CR=W3_DMA_REQUIRED_CR;stream_regs.NDTR=255U;tim_regs.CR1=1U;
    adc_regs.CR2=W3_ADC_REQUIRED_CR2;g_r2_w3_result.phase=R2_W3_RUNNING;
    g_r2_w3_result.epoch_before=100U;
}
static void Enter(uint32_t seq)
{
    stream_regs.CR=W3_DMA_REQUIRED_CR | ((seq & 1U) ? DMA_SxCR_CT : 0U);
    dma_regs.LISR=DMA_LISR_TCIF0;
    dwt_regs.CYCCNT=100U+seq*R2_W3_BLOCK_CYCLES+500U;
    R2_W3_IrqEnter(dma_regs.LISR);
    dma_regs.LISR=0U; /* idealized successful HAL TC flag clear */
}
static int Happy(void)
{
    uint32_t seq,j;
    Setup();
    for(seq=1U;seq<=8U;++seq){
        for(j=0U;j<256U;++j){r2_w3_buffers[seq-1U].samples[j]=(uint16_t)(j&7U);}
        Enter(seq);Completed(&hdma_adc1,(seq&1U)^1U);R2_W3_IrqExit();
        CHECK(g_r2_w3_result.fault_bits==0U);CHECK(g_r2_w3_result.rebind_count==seq);CHECK(mask==0U);
    }
    CHECK((tim_regs.CR1&1U)==0U);CHECK(g_r2_w3_result.bounded_stop_requested==1U);
    CHECK(stream_regs.M0AR==Address(8U)&&stream_regs.M1AR==Address(9U));
    g_r2_w3_result.quiet_tc_count=8U;g_r2_w3_result.quiet_rebind_count=8U;
    stream_regs.CR &= ~DMA_SxCR_EN;
    Finalize();CHECK(g_r2_w3_result.fault_bits==0U);CHECK(g_r2_w3_result.full_sample_count==2048U);
    return 0;
}
int main(void)
{
    uint32_t m0,m1;
    CHECK(Happy()==0);
    Setup();m0=stream_regs.M0AR;m1=stream_regs.M1AR;Enter(1U);
    stream_regs.CR &= ~DMA_SxCR_CT;
    Completed(&hdma_adc1,0U);CHECK(g_r2_w3_result.fault_bits!=0U);CHECK(g_r2_w3_result.rebind_count==0U);
    CHECK(stream_regs.M0AR==m0 && stream_regs.M1AR==m1);CHECK(mask==0U);
    Setup();m0=stream_regs.M0AR;m1=stream_regs.M1AR;Enter(1U);
    dwt_regs.CYCCNT += 2U*R2_W3_BLOCK_CYCLES;
    Completed(&hdma_adc1,0U);CHECK(g_r2_w3_result.trace[0].guard_status==R2_W3_GUARD_TIME);
    CHECK(stream_regs.M0AR==m0 && stream_regs.M1AR==m1);CHECK(mask==0U);
    Setup();Enter(1U);stream_regs.NDTR=1U;Completed(&hdma_adc1,0U);
    CHECK(g_r2_w3_result.trace[0].guard_status==R2_W3_GUARD_NDTR);CHECK(g_r2_w3_result.rebind_count==0U);
    Setup();Enter(1U);stream_regs.M0AR=Address(4U);Completed(&hdma_adc1,0U);
    CHECK(g_r2_w3_result.fault_bits==R2_W3_FAULT_ADDRESS);CHECK(g_r2_w3_result.rebind_count==0U);
    Setup();dma_regs.LISR=DMA_LISR_TEIF0|DMA_LISR_TCIF0;R2_W3_IrqEnter(dma_regs.LISR);
    CHECK(g_r2_w3_result.fault_bits==R2_W3_FAULT_DMA);CHECK((tim_regs.CR1&1U)==0U);
    Setup();Enter(1U);Completed(&hdma_adc1,0U);Completed(&hdma_adc1,0U);
    CHECK(g_r2_w3_result.fault_bits!=0U);CHECK(g_r2_w3_result.rebind_count==1U);
    CHECK(Happy()==0);r2_w3_buffers[2].guard_hi=0U;Finalize();CHECK(g_r2_w3_result.canary_errors==1U);
    CHECK(g_r2_w3_result.fault_bits!=0U);
    puts("Actual adapter mocked-register sequencing: 8 scenarios PASS (not hardware)");
    return 0;
}
