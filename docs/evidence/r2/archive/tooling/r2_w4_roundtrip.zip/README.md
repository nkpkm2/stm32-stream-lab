# R2-W4 READY / PROCESSING / FREE Round-Trip Package

This package adds a bounded R2-W4 profile on top of the hardware-verified W3 checkpoint.

It introduces real static FreeRTOS FreeBufferQueue and ReadyQueue objects, a minimal Processing task, and a W4-only `traceQUEUE_SEND` completion adapter. The default firmware profile remains R1. W3 remains separately buildable.

The W4 hardware experiment uses K=4, six active physical buffers, 64 admitted blocks, and no DSP or deliberate capacity-exhaustion workload. An empty FreeBufferQueue is a W4 failure; the controlled capacity-drop path is reserved for W5.

Before hardware use, run the installed `tools/r2/verify_w4.ps1` Native, W4Target, W3Regression, and R1Baseline profiles.
