[CmdletBinding()]
param(
    [string]$Repo = 'E:\Projects\stm32-stream-lab'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$git = 'C:\Program Files\Git\cmd\git.exe'
$expectedHead = 'f5d0f086dae94d2f244f8366a65aa32c511fd5be'
$expectedR1Pass = '5ebf62e90b31e262f44013afb594a430061f139a'
$payloadRoot = Join-Path $PSScriptRoot 'payload'

function Git-Lines {
    param([string[]]$Arguments)
    $old = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $lines = @(& $git -C $Repo @Arguments)
        $rc = $LASTEXITCODE
    } finally { $ErrorActionPreference = $old }
    if ($rc -ne 0) { throw ('Git failed: {0}' -f ($Arguments -join ' ')) }
    return $lines
}

function Assert-Hash {
    param([string]$Path, [string]$Expected)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw ('File missing: {0}' -f $Path)
    }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $Expected.ToLowerInvariant()) {
        throw ('SHA256 mismatch: {0}; observed {1}' -f $Path, $actual)
    }
}

function Changed-Paths {
    $lines = @(Git-Lines -Arguments @('status','--porcelain=v1','--untracked-files=all'))
    return @(
        $lines | ForEach-Object {
            if ($_.Length -ge 4) { $_.Substring(3).Replace('\','/') }
        }
    ) | Sort-Object
}

Write-Host '=== R2-W4 ROUND-TRIP INTEGRATION INSTALLATION ==='

try {
    $Repo = (Resolve-Path -LiteralPath $Repo).Path
    $head = @(Git-Lines -Arguments @('rev-parse','HEAD'))[0]
    if ($head -ne $expectedHead) { throw ('Unexpected HEAD: {0}' -f $head) }

    if (@(Git-Lines -Arguments @('status','--porcelain=v1','--untracked-files=all')).Count -ne 0) {
        throw 'Working tree is not clean.'
    }
    if (@(Git-Lines -Arguments @('diff','--cached','--name-only')).Count -ne 0) {
        throw 'Staging area is not empty.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','main'))[0] -ne @(Git-Lines -Arguments @('rev-parse','origin/main'))[0]) {
        throw 'main and origin/main are not synchronized.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','r1-pass^{commit}'))[0] -ne $expectedR1Pass) {
        throw 'r1-pass mismatch.'
    }
    if (@(Git-Lines -Arguments @('tag','--list','r2-pass')).Count -ne 0) {
        throw 'r2-pass exists unexpectedly.'
    }

    $replacements = @(
        @{ Path = 'firmware/cubemx/CMakeLists.txt'; Hash = 'ebff6770179c8fc9203c5b66f2cab819f0c5de5d60cebc89cf767b73fe7cd05a' }
        @{ Path = 'firmware/cubemx/Core/Inc/FreeRTOSConfig.h'; Hash = '0597e59eaa50b8716e518a6ea11ff88834da26a42684d480890cf4787d78671b' }
        @{ Path = 'firmware/cubemx/Core/Src/main.c'; Hash = '56175f8497b94e10147bbfba3524e8ebcee9f1fe0a3b97f13da199b156e3bafb' }
        @{ Path = 'firmware/cubemx/Core/Src/stm32f4xx_it.c'; Hash = 'da006f6243d4006cefab9011026601f6561d45d0acb57541e3ca7c279ff19d0c' }
        @{ Path = 'tests/native/CMakeLists.txt'; Hash = 'dee174beae541ba37fc45826cfcc726be0c972d681134ae65ac8b7122dc20a2f' }
    )

    foreach ($entry in $replacements) {
        Assert-Hash -Path (Join-Path $Repo $entry.Path) -Expected $entry.Hash
    }

    $newPaths = @(
        'docs/evidence/r2/w4/PLAN.md'
        'firmware/acquisition/r2_w4_guard.h'
        'firmware/acquisition/r2_w4_roundtrip.c'
        'firmware/acquisition/r2_w4_roundtrip.h'
        'tests/native/test_r2_w4_model.c'
        'tools/r2/verify_w4.ps1'
    )
    foreach ($relative in $newPaths) {
        if (Test-Path -LiteralPath (Join-Path $Repo $relative)) {
            throw ('New W4 path already exists: {0}' -f $relative)
        }
    }

    $payloadChecks = @(
        @{ Path = 'docs/evidence/r2/w4/PLAN.md'; Hash = 'ce9d4be6e029640caa6250c24bc78781055ea2839c354ee4243b3bc0674b49c3' }
        @{ Path = 'firmware/acquisition/r2_w4_guard.h'; Hash = 'c6af990e228b7fbc46b0206ec85b0fe94ea88b48df46741cc4523bec79f5fb9e' }
        @{ Path = 'firmware/acquisition/r2_w4_roundtrip.c'; Hash = '546f237af2f38acaad41cab54032d21832d0a666870cb557980cfc28711e1e4d' }
        @{ Path = 'firmware/acquisition/r2_w4_roundtrip.h'; Hash = '2d4d59942a37806f897d57a537f14fca21e652ea1f22918587c3b0b7cabe5978' }
        @{ Path = 'firmware/cubemx/CMakeLists.txt'; Hash = '76968bbf55a35f16ef99622124d947fea00ee9f30ab45889ffb028fbcdcd3828' }
        @{ Path = 'firmware/cubemx/Core/Inc/FreeRTOSConfig.h'; Hash = '45ca0710bb5fc69eb62462b715f7837f621b3fc9afddbeaa5717da41e6a97638' }
        @{ Path = 'firmware/cubemx/Core/Src/main.c'; Hash = '44609dbe7d37f87ec5af77b8f9855ee90c0d15d834606c73d3f6a24a0928b210' }
        @{ Path = 'firmware/cubemx/Core/Src/stm32f4xx_it.c'; Hash = 'cd0d922a15a1c24158585c3b9bac3cf018d17d2edb55471550c5023c7aac9817' }
        @{ Path = 'tests/native/CMakeLists.txt'; Hash = 'ec6e0dc4577829d8802932f13d4b5dc9e40431d66f3b136325665524647c05a4' }
        @{ Path = 'tests/native/test_r2_w4_model.c'; Hash = '5c0db31454ebbe30cc0eb98b879a3ce28ca5d9187570d10c14eded0e3e3ce72e' }
        @{ Path = 'tools/r2/verify_w4.ps1'; Hash = '54f79f3d1375356fe1d0e3f44148bf8f6ed20bd18af492f7536b127022cee895' }
    )

    foreach ($entry in $payloadChecks) {
        Assert-Hash -Path (Join-Path $payloadRoot $entry.Path) -Expected $entry.Hash
    }
    Write-Host 'Payload SHA256: 11 / 11 verified'

    $replacementSet = @{}
    foreach ($entry in $replacements) { $replacementSet[$entry.Path] = $true }

    $protected = @{}
    foreach ($relative in @(Git-Lines -Arguments @('ls-files'))) {
        $normalized = $relative.Replace('\','/')
        if (-not $replacementSet.ContainsKey($normalized)) {
            $full = Join-Path $Repo $normalized
            if (Test-Path -LiteralPath $full -PathType Leaf) {
                $protected[$normalized] = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
            }
        }
    }
    $indexBefore = @(Git-Lines -Arguments @('write-tree'))[0]

    foreach ($entry in $payloadChecks) {
        $source = Join-Path $payloadRoot $entry.Path
        $destination = Join-Path $Repo $entry.Path
        $parent = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }

    foreach ($entry in $payloadChecks) {
        Assert-Hash -Path (Join-Path $Repo $entry.Path) -Expected $entry.Hash
    }

    foreach ($relative in $protected.Keys) {
        $full = Join-Path $Repo $relative
        if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
            throw ('Protected tracked file disappeared: {0}' -f $relative)
        }
        $afterHash = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
        if ($afterHash -ne $protected[$relative]) {
            throw ('Protected tracked file changed: {0}' -f $relative)
        }
    }

    $expectedChanges = @($payloadChecks | ForEach-Object { $_.Path }) | Sort-Object
    $actualChanges = Changed-Paths
    $diff = Compare-Object -ReferenceObject $expectedChanges -DifferenceObject $actualChanges
    if ($diff) {
        $diff | Format-Table
        throw 'Installed W4 working-tree scope is unexpected.'
    }

    $old = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $git -C $Repo diff --check
        $diffRc = $LASTEXITCODE
    } finally { $ErrorActionPreference = $old }
    if ($diffRc -ne 0) { throw 'git diff --check failed.' }

    if (@(Git-Lines -Arguments @('write-tree'))[0] -ne $indexBefore) {
        throw 'Git index content changed.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','HEAD'))[0] -ne $expectedHead) {
        throw 'HEAD changed during installation.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','r1-pass^{commit}'))[0] -ne $expectedR1Pass) {
        throw 'r1-pass changed during installation.'
    }

    Write-Host ''
    Write-Host 'R2-W4 ROUND-TRIP INTEGRATION INSTALLATION: PASS'
    Write-Host 'Repository files: 11; replacements: 5; new: 6'
    Write-Host 'Protected tracked file bytes: unchanged'
    Write-Host 'W1/W2/W3 source modules and IOC: unchanged'
    Write-Host 'W4 profile requires STREAM_LAB_R2_W4=ON; R1 remains default'
    Write-Host 'FreeRTOS traceQUEUE_SEND hook is enabled only in W4 profile'
    Write-Host 'git diff --check: PASS'
    Write-Host 'Git index, HEAD, r1-pass, and r2-pass state: unchanged'
    Write-Host 'No build, flash, reset, commit, push, or MCU operation.'
} catch {
    Write-Host ''
    Write-Host 'R2-W4 ROUND-TRIP INTEGRATION INSTALLATION: FAIL'
    Write-Host $_.Exception.Message
    Write-Host 'Do not build, flash, commit, or begin W5.'
    exit 1
}
