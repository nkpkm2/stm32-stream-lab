# R2-W1: standalone BufferPool ownership core

This package was implemented by the development mentor. It installs four NEW
repository files only. It does not edit the accepted R1 firmware or connect the
new module to the STM32 build.

## Installed files

- firmware/buffer_pool/r2_buffer_pool.h
- firmware/buffer_pool/r2_buffer_pool.c
- tests/native/CMakeLists.txt
- tests/native/test_r2_buffer_pool.c

The install helper, this README, and assistant-side verification logs stay in
this extracted package. The C module and the executable tests go into the repo.
Keep this package until the later local test/evidence checkpoint is complete.
The tests' authoritative rerun entry point is tests/native/CMakeLists.txt; the
installer is not needed to build or rerun an already installed module.

## Baseline and scope

Expected local main: e4706fca69b39197ebb2d3f5c56946b5ae1e45b3
Known-good r1-pass: 5ebf62e90b31e262f44013afb594a430061f139a
Known-good r0-pass: 9ade715d6f3035cd60512bf2ec4dd1c226436af8

The installer checks local refs; it does NOT fetch or claim a fresh remote check.
It refuses dirty state or existing destination files and does not stage, commit,
push, build, flash, connect a debugger, or change the caller's current directory.
It compares the SHA256 of every existing tracked file before and after copying.

W1 holds metadata only: no sample arrays, registers, queue implementation,
FreeRTOS, HAL, DSP, dynamic allocation, locks, or ISR integration.
This is an ownership model, not a complete implementation of R2.

## Model contract

K is 1, 2, 4, or 8; P = K + 2; maximum IDs = 10.
At stable active-pool API boundaries:

- Exactly two buffers are DMA_OWNED.
- FREE + READY + PROCESSING = K.
- IDs at or beyond P are INACTIVE.
- Activation gives model DMA ownership to B0/B1, not a hardware slot binding.
- Activation of an already active model is rejected; reset is explicit.
- Reset is only for a quiescent/offline model, not runtime STOP or recovery.
- FindFree chooses the lowest FREE ID without changing ownership.
- CommitDmaRotation validates both IDs and states before changing either.
- ClaimReady is READY -> PROCESSING.
- ReleaseProcessing is PROCESSING -> FREE; double release is rejected.
- Illegal calls change only the saturating violation count.
- NO_FREE_BUFFER is normal and does not change state or violation count.
- Query output objects are independent copies; failure leaves outputs untouched.

All calls require external serialization. A pair of C assignments is NOT a CPU
atomic transaction. Hardware/queue commit points and ISR/task synchronization
are later integration work. FindFree is not a second FreeBufferQueue allocator;
ReleaseProcessing is not a substitute for CompleteAndReleaseBlock.
No lease/generation validation is implemented. Inactive/out-of-range IDs and
invalid current-state operations are detected, but an old numeric ID that has
been reused into a compatible state cannot be recognized as stale by W1 alone.

## Tests

24 behavioral test cases plus one expected-failure assertion probe are
registered with CTest. CHECK is independent of assert/NDEBUG. The expected-
failure probe exits nonzero; only that probe uses CTest WILL_FAIL.

Coverage includes every required K, initialization, illegal K/IDs/transitions,
failure-atomic rotation, double release, output preservation, exhaustion and
return, reset, copied snapshots, 1,728 directed ID-pair/fixture combinations,
and 40,000 deterministic model operations (10,000 for each K).
Tests compare logical snapshot fields rather than relying on C struct padding.
These tests do not claim exhaustive state-space proof or hardware race proof.

## Host native build

Run from the repository root, using a HOST C compiler. Do not pass the STM32
arm-none-eabi toolchain file. Use a new build directory for each compiler/profile.
For example, when a native gcc or clang is already available:

    cmake -S tests/native -B build/r2-w1-native -G Ninja -DCMAKE_BUILD_TYPE=Debug
    cmake --build build/r2-w1-native
    ctest --test-dir build/r2-w1-native --output-on-failure

For a Visual Studio multi-config generator, build with --config Debug and pass
-C Debug to ctest. MSVC is supported by the CMake warning policy but has NOT been
executed in the assistant environment. Host compiler discovery on the student's
Windows machine must occur before that environment can be called validated.

Optional assistant-tested sanitizer profile for non-MSVC GCC/Clang:

    cmake -S tests/native -B build/r2-w1-sanitized -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=clang -DR2_NATIVE_SANITIZERS=ON
    cmake --build build/r2-w1-sanitized
    ctest --test-dir build/r2-w1-sanitized --output-on-failure

CMake/CTest execution semantics: official CMake documentation, add_test,
enable_testing, and ctest(1). No new dependency beyond a host compiler, CMake,
and the selected build tool is required by these four files.

## Verification already performed

See verification/verification.json and the per-profile logs.
Assistant Linux environment: GCC 14.2.0 / Clang 17.0.0,
CMake 3.31.6 / Ninja 1.12.1.

- GCC Debug: 25/25 CTest cases passed; all-cases executable passed.
- GCC Release: 25/25 passed; all-cases executable passed.
- Clang Debug: 25/25 passed; all-cases executable passed.
- Clang Release: 25/25 passed; all-cases executable passed.
- Clang AddressSanitizer + UndefinedBehaviorSanitizer: 25/25 passed;
  all-cases executable passed with no reported sanitizer error.

Student Windows execution: NOT RUN by the assistant.
Windows PowerShell 5.1 execution: NOT RUN by the assistant.
The launch instructions perform a local PowerShell parser check before install.
MSVC execution: NOT RUN.
Hardware validation: NOT RUN and not within W1.
No local Windows PASS or R2 gate PASS is implied by these assistant-side tests.

## Today's five-line work plan

Current Gate: R2
Known-good baseline: R1 PASS
Today's objective: verify a standalone BufferPool ownership model with native tests
Most dangerous assumption: bookkeeping transactions could be mistaken for hardware ownership commits
Pass condition: local native tests pass for K=1/2/4/8 and rejected operations preserve ownership
