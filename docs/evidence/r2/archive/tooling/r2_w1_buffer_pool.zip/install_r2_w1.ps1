#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$Repo = 'E:\Projects\stm32-stream-lab',
    [string]$ExpectedHead = 'e4706fca69b39197ebb2d3f5c56946b5ae1e45b3'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$gitCommand = Get-Command git.exe -CommandType Application -ErrorAction SilentlyContinue
if ($null -eq $gitCommand) {
    $gitCommand = Get-Command git -CommandType Application -ErrorAction Stop
}
$Git = $gitCommand.Source
$Repo = (Resolve-Path -LiteralPath $Repo -ErrorAction Stop).Path
$Payload = Join-Path $PSScriptRoot 'payload'
$R0 = '9ade715d6f3035cd60512bf2ec4dd1c226436af8'
$R1 = '5ebf62e90b31e262f44013afb594a430061f139a'
$Files = @(
    'firmware/buffer_pool/r2_buffer_pool.h',
    'firmware/buffer_pool/r2_buffer_pool.c',
    'tests/native/CMakeLists.txt',
    'tests/native/test_r2_buffer_pool.c'
)
$createdFiles = New-Object 'System.Collections.Generic.List[string]'
$createdDirs = New-Object 'System.Collections.Generic.List[string]'
$hashes = @{}
$verified = $false

function Invoke-Git {
    param([string[]]$GitArgs)
    $output = @(& $Git -C $Repo @GitArgs)
    $code = $LASTEXITCODE
    if ($code -ne 0) {
        throw ('git {0} failed with exit code {1}.' -f ($GitArgs -join ' '), $code)
    }
    return $output
}

function Get-Hash {
    param([string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
}

try {
    Write-Output '=== R2-W1 OWNERSHIP MODEL INSTALLATION ==='
    $branch = (Invoke-Git -GitArgs @('branch', '--show-current')) -join ''
    $head = (Invoke-Git -GitArgs @('rev-parse', 'HEAD')) -join ''
    if ($branch -ne 'main' -or $head -ne $ExpectedHead) {
        throw ('Expected clean main at {0}; found {1} at {2}.' -f $ExpectedHead, $branch, $head)
    }
    $status = @(Invoke-Git -GitArgs @('status', '--porcelain=v1', '--untracked-files=all'))
    if ($status.Count -ne 0) {
        $status | Write-Output
        throw 'Working tree or index is not clean. No installation permitted.'
    }
    $origin = (Invoke-Git -GitArgs @('rev-parse', 'refs/remotes/origin/main')) -join ''
    if ($origin -ne $head) {
        throw 'Local main differs from the locally recorded origin/main.'
    }
    if (((Invoke-Git -GitArgs @('rev-parse', 'r0-pass^{commit}')) -join '') -ne $R0) {
        throw 'r0-pass target mismatch.'
    }
    if (((Invoke-Git -GitArgs @('rev-parse', 'r1-pass^{commit}')) -join '') -ne $R1) {
        throw 'r1-pass target mismatch.'
    }
    Invoke-Git -GitArgs @('merge-base', '--is-ancestor', $R1, $head) | Out-Null
    Write-Output ('Baseline HEAD: {0}' -f $head)
    Write-Output 'R0/R1 local gate targets: verified'

    # Authenticate the four payload copies before making any repository writes.
    $manifest = Join-Path $PSScriptRoot 'payload.sha256'
    foreach ($line in [System.IO.File]::ReadAllLines($manifest)) {
        $m = [regex]::Match($line, '^([0-9a-f]{64})  (.+)$')
        if (-not $m.Success) { throw 'Malformed payload manifest.' }
        $relative = $m.Groups[2].Value
        if (($Files -notcontains $relative) -or $hashes.ContainsKey($relative)) {
            throw ('Unexpected or duplicate manifest path: {0}' -f $relative)
        }
        $hashes.Add($relative, $m.Groups[1].Value)
    }
    if ($hashes.Count -ne $Files.Count) { throw 'Payload manifest is incomplete.' }
    foreach ($relative in $Files) {
        $src = Join-Path $Payload $relative
        $dst = Join-Path $Repo $relative
        if (-not (Test-Path -LiteralPath $src -PathType Leaf)) {
            throw ('Missing payload file: {0}' -f $relative)
        }
        if (Test-Path -LiteralPath $dst) {
            throw ('Refusing to overwrite existing path: {0}' -f $relative)
        }
        if ((Get-Hash $src) -ne $hashes[$relative]) {
            throw ('Payload hash mismatch: {0}' -f $relative)
        }
        $text = [System.IO.File]::ReadAllText($src)
        if ([regex]::IsMatch($text, '[^\x00-\x7f]') -or
            [regex]::IsMatch($text, '[ \t]+(?=\r?$)', [System.Text.RegularExpressions.RegexOptions]::Multiline)) {
            throw ('Payload is not ASCII / trailing-whitespace clean: {0}' -f $relative)
        }
        # A new source must not disappear into an ignore rule.
        & $Git -C $Repo check-ignore -q -- $relative
        $ignoreCode = $LASTEXITCODE
        if ($ignoreCode -eq 0) { throw ('Payload target is ignored: {0}' -f $relative) }
        if ($ignoreCode -ne 1) { throw 'git check-ignore failed.' }
    }

    # Stronger than comparing status strings: preserve existing tracked bytes.
    $existingHashes = @{}
    $tracked = @(Invoke-Git -GitArgs @('-c', 'core.quotePath=false', 'ls-files'))
    foreach ($relative in $tracked) {
        $path = Join-Path $Repo $relative
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw ('Tracked file is unavailable: {0}' -f $relative)
        }
        $existingHashes.Add($relative, (Get-Hash $path))
    }

    foreach ($relative in $Files) {
        $dst = Join-Path $Repo $relative
        $parent = Split-Path -Parent $dst
        $missing = New-Object 'System.Collections.Generic.List[string]'
        while (-not (Test-Path -LiteralPath $parent -PathType Container)) {
            $missing.Add($parent)
            $parent = Split-Path -Parent $parent
        }
        for ($n = $missing.Count - 1; $n -ge 0; $n--) {
            [System.IO.Directory]::CreateDirectory($missing[$n]) | Out-Null
            $createdDirs.Add($missing[$n])
        }
        # false = fail rather than overwrite, even if a race created the file.
        [System.IO.File]::Copy((Join-Path $Payload $relative), $dst, $false)
        $createdFiles.Add($relative)
        if ((Get-Hash $dst) -ne $hashes[$relative]) {
            throw ('Installed file hash mismatch: {0}' -f $relative)
        }
    }

    foreach ($relative in $existingHashes.Keys) {
        if ((Get-Hash (Join-Path $Repo $relative)) -ne $existingHashes[$relative]) {
            throw ('Existing tracked bytes changed: {0}' -f $relative)
        }
    }
    Invoke-Git -GitArgs @('diff', '--exit-code', '--quiet') | Out-Null
    Invoke-Git -GitArgs @('diff', '--cached', '--exit-code', '--quiet') | Out-Null
    $after = @(Invoke-Git -GitArgs @('status', '--porcelain=v1', '--untracked-files=all'))
    $expectedStatus = @($Files | ForEach-Object { '?? ' + $_ } | Sort-Object)
    if (($after.Count -ne 4) -or
        (($after | Sort-Object) -join "`n") -cne ($expectedStatus -join "`n")) {
        $after | Write-Output
        throw 'Final status is not the exact four new untracked files.'
    }
    if (((Invoke-Git -GitArgs @('rev-parse', 'HEAD')) -join '') -ne $head -or
        ((Invoke-Git -GitArgs @('rev-parse', 'r1-pass^{commit}')) -join '') -ne $R1 -or
        ((Invoke-Git -GitArgs @('rev-parse', 'r0-pass^{commit}')) -join '') -ne $R0) {
        throw 'HEAD or a gate tag changed during installation.'
    }
    $verified = $true
    Write-Output ''
    Write-Output 'R2-W1 INSTALLATION: PASS'
    Write-Output 'New files: 4; payload SHA256: 4/4 verified'
    Write-Output 'All existing tracked file bytes: unchanged'
    Write-Output 'R1 firmware / IOC / CMake / IRQ / gate tags: untouched'
    Write-Output 'Git index: unchanged; new files are NOT yet committed'
    Write-Output 'Local Windows native tests: NOT RUN'
    Write-Output 'No build, flash, commit, push, or MCU operation was performed.'
}
catch {
    # Roll back only files this invocation created, and only if still identical.
    # Never remove a pre-existing file or use git reset / git clean.
    if (-not $verified) {
        foreach ($relative in $createdFiles) {
            $path = Join-Path $Repo $relative
            if ((Test-Path -LiteralPath $path -PathType Leaf) -and
                ((Get-Hash $path) -eq $hashes[$relative])) {
                Remove-Item -LiteralPath $path -ErrorAction Stop
            }
        }
        for ($n = $createdDirs.Count - 1; $n -ge 0; $n--) {
            $dir = $createdDirs[$n]
            if ((Test-Path -LiteralPath $dir -PathType Container) -and
                (@(Get-ChildItem -LiteralPath $dir -Force)).Count -eq 0) {
                [System.IO.Directory]::Delete($dir)
            }
        }
    }
    Write-Output 'R2-W1 INSTALLATION: FAIL'
    throw
}

# Read-only discovery; a candidate on PATH is not a validated native compiler.
Write-Output ''
Write-Output '=== HOST NATIVE TOOLCHAIN CANDIDATES ==='
foreach ($name in @('cl.exe', 'clang.exe', 'gcc.exe', 'cc.exe')) {
    $candidates = @(Get-Command $name -CommandType Application -All -ErrorAction SilentlyContinue)
    if ($candidates.Count -eq 0) {
        Write-Output ('{0}: NOT FOUND ON PATH' -f $name)
    }
    else {
        foreach ($candidate in $candidates) {
            Write-Output ('{0}: {1}' -f $name, $candidate.Source)
        }
    }
}
Write-Output 'Arm cross-compiler availability does not establish a host native toolchain.'
Write-Output ('Current PowerShell directory retained: {0}' -f (Get-Location).Path)
