R2-W6 Mandatory K Matrix package

Purpose:
  Install one parameterized W6 implementation for the mandatory K matrix.

Matrix:
  K = 1, 2, 4, 8
  Mode = NORMAL, DROP

Important boundary:
  W6 closes the mandatory K matrix only. It does not by itself close all R2
  acceptance work. Worst-permitted control-traffic service-margin evidence
  and final R2 stress/soak/closeout remain separate acceptance items.

Installation:
  Run install_r2_w6.ps1 from Windows PowerShell 5.1.

The installer does not build, flash, reset, commit, push, or create r2-pass.
