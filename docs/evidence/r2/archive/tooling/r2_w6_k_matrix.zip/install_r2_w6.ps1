[CmdletBinding()]
param(
    [string]$Repo = 'E:\Projects\stm32-stream-lab'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$expectedHead = '2752c0e915ab4725cc13e400d16fe47b14adfd4e'
$expectedR1Pass = '5ebf62e90b31e262f44013afb594a430061f139a'
$git = (Get-Command git.exe -ErrorAction Stop).Source
$payloadRoot = Join-Path $PSScriptRoot 'payload'

$payloadChecks = @(
    [PSCustomObject]@{ Path='firmware/acquisition/r2_w6_guard.h'; Hash='5AA5A03435B1E0A4ABEDAB7F04D63AD696E4CC751CA25A2D36B408E4075552C4'; Kind='new' },
    [PSCustomObject]@{ Path='firmware/acquisition/r2_w6_matrix.c'; Hash='2BD42D4B477D99030EAACF892354EDCBB13EADC9B4A667A963945329D705795D'; Kind='new' },
    [PSCustomObject]@{ Path='firmware/acquisition/r2_w6_matrix.h'; Hash='3AE0544E05E9DA0E2048B17D71B0259E9BA719BA70C9715D90215B087AC5716A'; Kind='new' },
    [PSCustomObject]@{ Path='firmware/cubemx/CMakeLists.txt'; Hash='31FB874FC7BC29A1F22873325CEF4384764E1EE457CF2746DFE9A32E6FB674BB'; Kind='replace' },
    [PSCustomObject]@{ Path='firmware/cubemx/Core/Inc/FreeRTOSConfig.h'; Hash='7AD42D70F9E613A7DDC915C7C8D4D9EE61AF7BFB416CD184832A2CEDE3F33333'; Kind='replace' },
    [PSCustomObject]@{ Path='firmware/cubemx/Core/Src/main.c'; Hash='C8E17E002496EB18D94D5C34475ACCC1AB59002B2445E30F43B057F711E6E9B9'; Kind='replace' },
    [PSCustomObject]@{ Path='firmware/cubemx/Core/Src/stm32f4xx_it.c'; Hash='6D1DB15FE76DB016AD319A072FAF18F3729E961666F069EF7F56DF234C263698'; Kind='replace' },
    [PSCustomObject]@{ Path='tests/native/CMakeLists.txt'; Hash='63893A3CE430CD6CC6FC5BA998B5A9B7F744A27DE555A305290F4751115A5587'; Kind='replace' },
    [PSCustomObject]@{ Path='tests/native/test_r2_w6_matrix.c'; Hash='A2013BFD33B581A870D86A93EFAF7156DA507A9B414728457C801310A7DC44C9'; Kind='new' },
    [PSCustomObject]@{ Path='tools/r2/verify_w6.ps1'; Hash='D36DFCC3F0D9A44E85606E23634787C34E90AF459DEDFEA108D906C1DA4CF5E5'; Kind='new' },
    [PSCustomObject]@{ Path='docs/evidence/r2/w6/PLAN.md'; Hash='F51A8B20CCA5033EA1FAED8BE86A2DC8FA2476025AF82A1E7E0951E1C954D85F'; Kind='new' }
)

$oldReplacementHashes = @{
    'firmware/cubemx/CMakeLists.txt' = 'A12AD2A41B5AE8FFEBD8C2FA961184276EBFA3F38184828D22B6A2543256CA67'
    'firmware/cubemx/Core/Inc/FreeRTOSConfig.h' = '3738BA40F56B3581DF408F13C34FD92D1187296CFDEC2FA96F05B4170E54DD21'
    'firmware/cubemx/Core/Src/main.c' = '55099CCE26939DAEB1C21F51351A81F1DD4EDBB5725040768442C06B5BDBECA0'
    'firmware/cubemx/Core/Src/stm32f4xx_it.c' = '45EBC35BF0E3F4052192E7EE6D1793E77266D97926DFF54B16DA85C95967255D'
    'tests/native/CMakeLists.txt' = '18FBD8CA265F0325569E968940C5216E8F422AD8CB982CC76C5A550A83FE2D15'
}

function Git-Lines {
    param([string[]]$Arguments)
    $old = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $lines = @(& $git -C $Repo @Arguments)
        $rc = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $old
    }
    if ($rc -ne 0) {
        throw ('Git failed: {0}' -f ($Arguments -join ' '))
    }
    return $lines
}

function Relative-Normalized {
    param([string]$Path)
    return $Path.Replace('\','/')
}

try {
    Write-Output '=== R2-W6 MANDATORY K-MATRIX INSTALLATION ==='

    $Repo = (Resolve-Path -LiteralPath $Repo).Path
    Set-Location -LiteralPath $Repo

    $head = @(Git-Lines -Arguments @('rev-parse','HEAD'))[0]
    if ($head -ne $expectedHead) {
        throw "Unexpected HEAD: $head"
    }

    if (@(Git-Lines -Arguments @('status','--porcelain=v1','--untracked-files=all')).Count -ne 0) {
        throw 'Working tree is not clean.'
    }

    if (@(Git-Lines -Arguments @('diff','--cached','--name-only')).Count -ne 0) {
        throw 'Git staging area is not empty.'
    }

    $r1 = @(Git-Lines -Arguments @('rev-parse','r1-pass^{commit}'))[0]
    if ($r1 -ne $expectedR1Pass) {
        throw "r1-pass moved unexpectedly: $r1"
    }

    if (@(Git-Lines -Arguments @('tag','--list','r2-pass')).Count -ne 0) {
        throw 'r2-pass exists unexpectedly.'
    }

    foreach ($entry in $payloadChecks) {
        $payloadPath = Join-Path $payloadRoot $entry.Path
        if (-not (Test-Path -LiteralPath $payloadPath -PathType Leaf)) {
            throw "Payload file missing: $($entry.Path)"
        }
        $actual = (Get-FileHash -LiteralPath $payloadPath -Algorithm SHA256).Hash
        if ($actual -ne $entry.Hash) {
            throw "Payload SHA256 mismatch: $($entry.Path)"
        }
    }

    Write-Output 'Payload SHA256: 11 / 11 verified'

    foreach ($relative in $oldReplacementHashes.Keys) {
        $full = Join-Path $Repo $relative
        $actual = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
        if ($actual -ne $oldReplacementHashes[$relative]) {
            throw "Baseline replacement-input hash mismatch: $relative"
        }
    }

    $tracked = @(Git-Lines -Arguments @('ls-files'))
    $protectedBefore = @{}
    foreach ($relative in $tracked) {
        $normalized = Relative-Normalized $relative
        if (-not $oldReplacementHashes.ContainsKey($normalized)) {
            $full = Join-Path $Repo $relative
            if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
                throw "Tracked file missing before install: $relative"
            }
            $protectedBefore[$normalized] = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
        }
    }

    foreach ($entry in $payloadChecks) {
        $destination = Join-Path $Repo $entry.Path
        if (($entry.Kind -eq 'new') -and (Test-Path -LiteralPath $destination)) {
            throw "Refusing to overwrite new W6 path: $($entry.Path)"
        }
        $parent = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }
        Copy-Item -LiteralPath (Join-Path $payloadRoot $entry.Path) -Destination $destination -Force
    }

    foreach ($entry in $payloadChecks) {
        $destination = Join-Path $Repo $entry.Path
        $actual = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
        if ($actual -ne $entry.Hash) {
            throw "Installed SHA256 mismatch: $($entry.Path)"
        }
    }

    foreach ($relative in $protectedBefore.Keys) {
        $full = Join-Path $Repo $relative
        $actual = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
        if ($actual -ne $protectedBefore[$relative]) {
            throw "Protected tracked file changed unexpectedly: $relative"
        }
    }

    $expectedChanges = @($payloadChecks | ForEach-Object { $_.Path }) | Sort-Object
    $actualChanges = @(
        Git-Lines -Arguments @('status','--porcelain=v1','--untracked-files=all') |
        ForEach-Object {
            if ($_.Length -ge 4) { $_.Substring(3).Replace('\','/') }
        }
    ) | Sort-Object

    $scopeDiff = Compare-Object -ReferenceObject $expectedChanges -DifferenceObject $actualChanges
    if ($scopeDiff) {
        $scopeDiff | Format-Table
        throw 'Installed W6 repository change scope is unexpected.'
    }

    $old = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $git -C $Repo diff --check
        $diffRc = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $old
    }
    if ($diffRc -ne 0) {
        throw 'git diff --check failed.'
    }

    if (@(Git-Lines -Arguments @('diff','--cached','--name-only')).Count -ne 0) {
        throw 'Installer changed the Git index.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','HEAD'))[0] -ne $expectedHead) {
        throw 'Installer changed HEAD.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','r1-pass^{commit}'))[0] -ne $expectedR1Pass) {
        throw 'Installer changed r1-pass.'
    }
    if (@(Git-Lines -Arguments @('tag','--list','r2-pass')).Count -ne 0) {
        throw 'Installer created r2-pass unexpectedly.'
    }

    Write-Output ''
    Write-Output 'R2-W6 MANDATORY K-MATRIX INSTALLATION: PASS'
    Write-Output 'Repository files: 11; replacements: 5; new: 6'
    Write-Output 'Protected tracked file bytes: unchanged'
    Write-Output 'W1/W2/W3/W4/W5 source modules and IOC: unchanged'
    Write-Output 'W6 profile is parameterized by K=1/2/4/8 and NORMAL/DROP mode'
    Write-Output 'R1 remains the default firmware profile'
    Write-Output 'FreeRTOS traceQUEUE_SEND selects W6 only when STREAM_LAB_R2_W6=ON'
    Write-Output 'git diff --check: PASS'
    Write-Output 'Git index, HEAD, r1-pass, and r2-pass state: unchanged'
    Write-Output 'No build, flash, reset, commit, push, or MCU operation.'
} catch {
    Write-Output ''
    Write-Output 'R2-W6 MANDATORY K-MATRIX INSTALLATION: FAIL'
    Write-Output $_.Exception.Message
    Write-Output 'Do not build, commit, or start the W6 hardware matrix.'
    exit 1
}
