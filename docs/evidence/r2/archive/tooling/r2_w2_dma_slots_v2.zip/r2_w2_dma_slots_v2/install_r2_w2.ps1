param(
    [string]$Repo = 'E:\Projects\stm32-stream-lab'
)

$ErrorActionPreference = 'Stop'
$git = 'C:\Program Files\Git\cmd\git.exe'
$expectedHead = '7e1ab05ac281312a32092380709c4733fe684492'
$expectedR1Pass = '5ebf62e90b31e262f44013afb594a430061f139a'
$expectedOldCmakeHash = '937C3C4BEB3541CA89077DF344FBCD190E83417B3F283E2AAC6C2C0E1725BA53'

try {
    Set-Location -LiteralPath $Repo
    Write-Output '=== R2-W2 DMA SLOT ABSTRACTION INSTALLATION ==='

    $head = (& $git rev-parse HEAD).Trim()
    if ($head -ne $expectedHead) {
        throw "Unexpected HEAD: $head"
    }

    $status = @(& $git status --porcelain=v1 --untracked-files=all)
    if ($status.Count -ne 0) {
        $status
        throw 'Working tree is not clean.'
    }

    $r1Pass = (& $git rev-parse 'r1-pass^{commit}').Trim()
    if ($r1Pass -ne $expectedR1Pass) {
        throw "r1-pass moved unexpectedly: $r1Pass"
    }

    $cmakePath = Join-Path $Repo 'tests\native\CMakeLists.txt'
    if (-not (Test-Path -LiteralPath $cmakePath -PathType Leaf)) {
        throw 'Existing native CMakeLists.txt is missing.'
    }

    $oldHash = (Get-FileHash -LiteralPath $cmakePath -Algorithm SHA256).Hash
    if ($oldHash -ne $expectedOldCmakeHash) {
        throw "Existing native CMakeLists.txt is not the reviewed W1 version: $oldHash"
    }

    $scriptDir = $PSScriptRoot
    $payload = Join-Path $scriptDir 'payload'

    $payloadChecks = @(
        @('firmware\acquisition\r2_dma_slots.h', '4892D171B54527234D7FCDB0024CABA39CF3306D451FC1D5AAA8FB5DBE499811')
        @('firmware\acquisition\r2_dma_slots.c', '39F4FAFF9169E2640EA81269428CB67F0ED7278C699973F662EF4AB745156C51')
        @('tests\native\test_r2_dma_slots.c', '85DD8A50394B2625734E68548A7B2DC0D6D05372AFE434D4022FF19B7A640245')
        @('tests\native\CMakeLists.txt', 'CB1A531ABFC9F192C17EE6650BB48FFF6C9FABFA763BC23DE9808EA3DAE43A52')
    )

    foreach ($check in $payloadChecks) {
        $relative = $check[0]
        $expectedHash = $check[1]
        $path = Join-Path $payload $relative

        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Payload file missing: $relative"
        }

        $actualHash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
        if ($actualHash -ne $expectedHash) {
            throw "Payload SHA256 mismatch for ${relative}: $actualHash"
        }
    }

    Write-Output 'Payload SHA256: 4 / 4 verified'

    $newHeader = Join-Path $Repo 'firmware\acquisition\r2_dma_slots.h'
    $newSource = Join-Path $Repo 'firmware\acquisition\r2_dma_slots.c'
    $newTest = Join-Path $Repo 'tests\native\test_r2_dma_slots.c'

    foreach ($path in @($newHeader, $newSource, $newTest)) {
        if (Test-Path -LiteralPath $path) {
            throw "Refusing to overwrite existing W2 path: $path"
        }
    }

    $trackedBefore = @(& $git ls-files)
    $hashBefore = @{}
    foreach ($relative in $trackedBefore) {
        $full = Join-Path $Repo $relative
        if (Test-Path -LiteralPath $full -PathType Leaf) {
            $hashBefore[$relative] = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
        }
    }

    Copy-Item -LiteralPath (Join-Path $payload 'firmware\acquisition\r2_dma_slots.h') -Destination $newHeader
    Copy-Item -LiteralPath (Join-Path $payload 'firmware\acquisition\r2_dma_slots.c') -Destination $newSource
    Copy-Item -LiteralPath (Join-Path $payload 'tests\native\test_r2_dma_slots.c') -Destination $newTest
    Copy-Item -LiteralPath (Join-Path $payload 'tests\native\CMakeLists.txt') -Destination $cmakePath -Force

    $expectedChanges = @(
        'firmware/acquisition/r2_dma_slots.c'
        'firmware/acquisition/r2_dma_slots.h'
        'tests/native/CMakeLists.txt'
        'tests/native/test_r2_dma_slots.c'
    ) | Sort-Object

    $after = @(& $git status --porcelain=v1 --untracked-files=all)
    $actualChanges = @(
        $after | ForEach-Object {
            if ($_.Length -ge 4) { $_.Substring(3) }
        }
    ) | Sort-Object

    $scopeDiff = Compare-Object -ReferenceObject $expectedChanges -DifferenceObject $actualChanges
    if ($scopeDiff) {
        $scopeDiff | Format-Table
        throw 'Unexpected repository change scope.'
    }

    foreach ($relative in $trackedBefore) {
        if ($relative -eq 'tests/native/CMakeLists.txt') {
            continue
        }
        $full = Join-Path $Repo $relative
        if (Test-Path -LiteralPath $full -PathType Leaf) {
            $afterHash = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
            if ($hashBefore[$relative] -ne $afterHash) {
                throw "Existing tracked file changed unexpectedly: $relative"
            }
        }
    }

    & $git diff --check
    if ($LASTEXITCODE -ne 0) {
        throw 'git diff --check failed.'
    }

    Write-Output ''
    Write-Output '============================================================'
    Write-Output 'R2-W2 DMA SLOT ABSTRACTION INSTALLATION: PASS'
    Write-Output '============================================================'
    Write-Output 'New production files: 2'
    Write-Output 'New native test file: 1'
    Write-Output 'Native CMakeLists.txt: extended for W2'
    Write-Output 'R1 acquisition implementation: untouched'
    Write-Output 'DMA ISR: untouched'
    Write-Output 'STM32 firmware CMake: untouched'
    Write-Output 'CubeMX IOC: untouched'
    Write-Output 'r1-pass: unchanged'
    Write-Output 'git diff --check: PASS'
    Write-Output ''
    Write-Output 'No build, flash, commit, push, or MCU operation was performed.'
}
catch {
    Write-Output ''
    Write-Output '============================================================'
    Write-Output 'R2-W2 DMA SLOT ABSTRACTION INSTALLATION: FAIL'
    Write-Output '============================================================'
    Write-Output $_.Exception.Message
    Write-Output ''
    Write-Output 'Do not build, commit, or begin W3.'
    exit 1
}
