# R2-W2 DMA Slot Abstraction

This package adds only the host-testable M0/M1 mapping and CT semantics layer.

It intentionally does not access STM32 DMA registers, change MxAR, mutate the
BufferPool, use FreeRTOS, or touch the R1 acquisition implementation.

Files changed by installation:

- `firmware/acquisition/r2_dma_slots.h` (new)
- `firmware/acquisition/r2_dma_slots.c` (new)
- `tests/native/test_r2_dma_slots.c` (new)
- `tests/native/CMakeLists.txt` (extended; W1 tests preserved)

The installer verifies the exact SHA256 of all four payload files before modifying the repository.
