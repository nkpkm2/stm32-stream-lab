# R2-W5 Directed Capacity-Drop Package

This package adds one bounded diagnostic profile for deliberate K=1
FreeBufferQueue exhaustion and controlled capacity drops.

Install only on repository HEAD:
`7ae9a562ff0eaeeeda4a80c1bea16a6d22d7203c`.

The default firmware profile remains R1. W5 requires
`STREAM_LAB_R2_W5=ON` and is mutually exclusive with W3/W4.

The installer does not build, flash, reset, commit, push, or touch gate tags.
