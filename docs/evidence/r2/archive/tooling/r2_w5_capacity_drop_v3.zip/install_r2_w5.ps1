[CmdletBinding()]
param(
    [string]$Repo = 'E:\Projects\stm32-stream-lab'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$git = 'C:\Program Files\Git\cmd\git.exe'
$expectedHead = '7ae9a562ff0eaeeeda4a80c1bea16a6d22d7203c'
$expectedR1Pass = '5ebf62e90b31e262f44013afb594a430061f139a'
$payloadRoot = Join-Path $PSScriptRoot 'payload'

function Git-Lines {
    param([string[]]$Arguments)
    $old = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $lines = @(& $git -C $Repo @Arguments)
        $rc = $LASTEXITCODE
    } finally { $ErrorActionPreference = $old }
    if ($rc -ne 0) { throw ('Git failed: {0}' -f ($Arguments -join ' ')) }
    return $lines
}

function Assert-Hash {
    param([string]$Path, [string]$Expected)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw ('File missing: {0}' -f $Path)
    }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $Expected.ToLowerInvariant()) {
        throw ('SHA256 mismatch: {0}; observed {1}' -f $Path, $actual)
    }
}

function Changed-Paths {
    $lines = @(Git-Lines -Arguments @('status','--porcelain=v1','--untracked-files=all'))
    return @(
        $lines | ForEach-Object {
            if ($_.Length -ge 4) { $_.Substring(3).Replace('\','/') }
        }
    ) | Sort-Object
}

Write-Host '=== R2-W5 CAPACITY-DROP INTEGRATION INSTALLATION ==='

try {
    $Repo = (Resolve-Path -LiteralPath $Repo).Path
    $head = @(Git-Lines -Arguments @('rev-parse','HEAD'))[0]
    if ($head -ne $expectedHead) { throw ('Unexpected HEAD: {0}' -f $head) }

    if (@(Git-Lines -Arguments @('status','--porcelain=v1','--untracked-files=all')).Count -ne 0) {
        throw 'Working tree is not clean.'
    }
    if (@(Git-Lines -Arguments @('diff','--cached','--name-only')).Count -ne 0) {
        throw 'Staging area is not empty.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','main'))[0] -ne @(Git-Lines -Arguments @('rev-parse','origin/main'))[0]) {
        throw 'main and origin/main are not synchronized.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','r1-pass^{commit}'))[0] -ne $expectedR1Pass) {
        throw 'r1-pass mismatch.'
    }
    if (@(Git-Lines -Arguments @('tag','--list','r2-pass')).Count -ne 0) {
        throw 'r2-pass exists unexpectedly.'
    }

    $replacements = @(
        @{ Path = 'firmware/cubemx/CMakeLists.txt'; Hash = '76968bbf55a35f16ef99622124d947fea00ee9f30ab45889ffb028fbcdcd3828' }
        @{ Path = 'firmware/cubemx/Core/Inc/FreeRTOSConfig.h'; Hash = '45ca0710bb5fc69eb62462b715f7837f621b3fc9afddbeaa5717da41e6a97638' }
        @{ Path = 'firmware/cubemx/Core/Src/main.c'; Hash = '44609dbe7d37f87ec5af77b8f9855ee90c0d15d834606c73d3f6a24a0928b210' }
        @{ Path = 'firmware/cubemx/Core/Src/stm32f4xx_it.c'; Hash = 'cd0d922a15a1c24158585c3b9bac3cf018d17d2edb55471550c5023c7aac9817' }
        @{ Path = 'tests/native/CMakeLists.txt'; Hash = 'ec6e0dc4577829d8802932f13d4b5dc9e40431d66f3b136325665524647c05a4' }
    )

    foreach ($entry in $replacements) {
        Assert-Hash -Path (Join-Path $Repo $entry.Path) -Expected $entry.Hash
    }

    $newPaths = @(
        'docs/evidence/r2/w5/PLAN.md'
        'firmware/acquisition/r2_w5_guard.h'
        'firmware/acquisition/r2_w5_capacity.c'
        'firmware/acquisition/r2_w5_capacity.h'
        'tests/native/test_r2_w5_model.c'
        'tools/r2/verify_w5.ps1'
    )
    foreach ($relative in $newPaths) {
        if (Test-Path -LiteralPath (Join-Path $Repo $relative)) {
            throw ('New W5 path already exists: {0}' -f $relative)
        }
    }

    $payloadChecks = @(
        @{ Path = 'docs/evidence/r2/w5/PLAN.md'; Hash = '75f567cb0feefa0c7e65a1aae1f7c85eaa635137971e8cf04083904c67e59ba2' }
        @{ Path = 'firmware/acquisition/r2_w5_guard.h'; Hash = 'f17a007417c9193ae23f1a482e3c65263feb83ea394493a1e0a2a026e06b5543' }
        @{ Path = 'firmware/acquisition/r2_w5_capacity.c'; Hash = 'f40ffb8651f17735022db29e0958836ecaf7a71bf78ff857b3991398ea440c54' }
        @{ Path = 'firmware/acquisition/r2_w5_capacity.h'; Hash = '24f2b2b8b0fd7a35b10dcd2a3a83a03f361c72aec18e3218ed375cae493de438' }
        @{ Path = 'firmware/cubemx/CMakeLists.txt'; Hash = 'a12ad2a41b5ae8ffebd8c2fa961184276ebfa3f38184828d22b6a2543256ca67' }
        @{ Path = 'firmware/cubemx/Core/Inc/FreeRTOSConfig.h'; Hash = '3738ba40f56b3581df408f13c34fd92d1187296cfdec2fa96f05b4170e54dd21' }
        @{ Path = 'firmware/cubemx/Core/Src/main.c'; Hash = '55099cce26939daeb1c21f51351a81f1dd4edbb5725040768442c06b5bdbeca0' }
        @{ Path = 'firmware/cubemx/Core/Src/stm32f4xx_it.c'; Hash = '45ebc35bf0e3f4052192e7ee6d1793e77266d97926dff54b16da85c95967255d' }
        @{ Path = 'tests/native/CMakeLists.txt'; Hash = '18fbd8ca265f0325569e968940c5216e8f422ad8cb982cc76c5a550a83fe2d15' }
        @{ Path = 'tests/native/test_r2_w5_model.c'; Hash = '27bbd545b050025a24610553d1b663a30429861c51ea6126d119ade6a13fa4e7' }
        @{ Path = 'tools/r2/verify_w5.ps1'; Hash = 'ab39e2e6f1991191768747c40265c0fa3cfac2e6c9b13ec4ae8d8e8b45d4c4e0' }
    )

    foreach ($entry in $payloadChecks) {
        Assert-Hash -Path (Join-Path $payloadRoot $entry.Path) -Expected $entry.Hash
    }
    Write-Host 'Payload SHA256: 11 / 11 verified'

    $replacementSet = @{}
    foreach ($entry in $replacements) { $replacementSet[$entry.Path] = $true }

    $protected = @{}
    foreach ($relative in @(Git-Lines -Arguments @('ls-files'))) {
        $normalized = $relative.Replace('\','/')
        if (-not $replacementSet.ContainsKey($normalized)) {
            $full = Join-Path $Repo $normalized
            if (Test-Path -LiteralPath $full -PathType Leaf) {
                $protected[$normalized] = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
            }
        }
    }
    $indexBefore = @(Git-Lines -Arguments @('write-tree'))[0]

    foreach ($entry in $payloadChecks) {
        $source = Join-Path $payloadRoot $entry.Path
        $destination = Join-Path $Repo $entry.Path
        $parent = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }

    foreach ($entry in $payloadChecks) {
        Assert-Hash -Path (Join-Path $Repo $entry.Path) -Expected $entry.Hash
    }

    foreach ($relative in $protected.Keys) {
        $full = Join-Path $Repo $relative
        if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
            throw ('Protected tracked file disappeared: {0}' -f $relative)
        }
        $afterHash = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash
        if ($afterHash -ne $protected[$relative]) {
            throw ('Protected tracked file changed: {0}' -f $relative)
        }
    }

    $expectedChanges = @($payloadChecks | ForEach-Object { $_.Path }) | Sort-Object
    $actualChanges = Changed-Paths
    $diff = Compare-Object -ReferenceObject $expectedChanges -DifferenceObject $actualChanges
    if ($diff) {
        $diff | Format-Table
        throw 'Installed W5 working-tree scope is unexpected.'
    }

    $old = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $git -C $Repo diff --check
        $diffRc = $LASTEXITCODE
    } finally { $ErrorActionPreference = $old }
    if ($diffRc -ne 0) { throw 'git diff --check failed.' }

    if (@(Git-Lines -Arguments @('write-tree'))[0] -ne $indexBefore) {
        throw 'Git index content changed.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','HEAD'))[0] -ne $expectedHead) {
        throw 'HEAD changed during installation.'
    }
    if (@(Git-Lines -Arguments @('rev-parse','r1-pass^{commit}'))[0] -ne $expectedR1Pass) {
        throw 'r1-pass changed during installation.'
    }

    Write-Host ''
    Write-Host 'R2-W5 CAPACITY-DROP INTEGRATION INSTALLATION: PASS'
    Write-Host 'Repository files: 11; replacements: 5; new: 6'
    Write-Host 'Protected tracked file bytes: unchanged'
    Write-Host 'W1/W2/W3/W4 source modules and IOC: unchanged'
    Write-Host 'W5 profile requires STREAM_LAB_R2_W5=ON; R1 remains default'
    Write-Host 'FreeRTOS traceQUEUE_SEND hook selects W4 or W5 only in those profiles'
    Write-Host 'git diff --check: PASS'
    Write-Host 'Git index, HEAD, r1-pass, and r2-pass state: unchanged'
    Write-Host 'No build, flash, reset, commit, push, or MCU operation.'
} catch {
    Write-Host ''
    Write-Host 'R2-W5 CAPACITY-DROP INTEGRATION INSTALLATION: FAIL'
    Write-Host $_.Exception.Message
    Write-Host 'Do not build, flash, commit, or begin W6.'
    exit 1
}
